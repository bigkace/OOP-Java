// Xử lý nhập xuất
public interface NhapXuat {
	void nhap();
	void xuat();
}
